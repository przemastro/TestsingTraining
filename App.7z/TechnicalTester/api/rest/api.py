from flask import Flask, jsonify, request
from flask_restful import reqparse, Api, Resource
from jsonBuilder import candidatesProcessed, addCandidate
import ConfigParser
from threading import *


app = Flask(__name__)
api = Api(app)


config = ConfigParser.RawConfigParser()
config.read('../resources/env.properties')
serverAddress = config.get('Server', 'server.address');
serverPort = int(config.get('Server', 'server.port'));
serverService = config.get('Server', 'server.service');


REST = {'data': candidatesProcessed()}

parser = reqparse.RequestParser()
parser.add_argument('name', type=str)
parser.add_argument('lastName', type=str)
parser.add_argument('level', type=str)
parser.add_argument('area', type=str)
parser.add_argument('salary', type=str)
parser.add_argument('grade', type=str)

class Rest(Resource):
    def get(self, rest_id):
        return jsonify(REST[rest_id])

class RestAddCandidate(Resource):
    def post(self):
        args = parser.parse_args()
        data = addCandidate(args['name'], args['lastName'], args['level'], args['area'], args['salary'], args['grade'])
        return jsonify(data)

api.add_resource(Rest, '/<rest_id>')
api.add_resource(RestAddCandidate, '/addCandidate')


# Handling COR requests
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,SessionId,Email')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    response.headers.add("Access-Control-Max-Age", "3600");
    response.headers.add("Access-Control-Allow-Headers", "x-requested-with");
    response.headers.add("Connection", "keep-alive");
    response.headers.add("Vary", "Accept-Encoding");
    return response


if __name__ == '__main__':
    app.run(debug=False, host=serverAddress, port=serverPort, threaded=True, use_reloader=True)

