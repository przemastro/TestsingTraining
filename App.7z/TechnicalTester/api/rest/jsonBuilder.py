import pyodbc
import ast
import ConfigParser
import time

config = ConfigParser.RawConfigParser()
config.read('../resources/env.properties')
dbAddress = config.get('DatabaseConnection', 'database.address');
queries = ConfigParser.RawConfigParser()
queries.read('../resources/queries.properties')
cnx = pyodbc.connect(dbAddress)
cursor = cnx.cursor()

def candidatesProcessed():
    try:
        cnx = pyodbc.connect(dbAddress)
        cursor = cnx.cursor()

        getIdsFromCandidatesProcessed = queries.get('DatabaseQueries', 'database.getIdsFromCandidatesProcessed');
        getIds = fetch_all(getIdsFromCandidatesProcessed)

        i = 0
        controller = ''
        if(len(getIds) != 0):
            for counter in getIds:
                id = str(counter)
                i = i + 1
                getName = (queries.get('DatabaseQueries', 'database.getName') + id)
                getLastName = (queries.get('DatabaseQueries', 'database.getLastName') + id)
                getAccepted = (queries.get('DatabaseQueries', 'database.getAccepted') + id)

                object = {'id': id, 'name': str(fetch_one(getName)), 'lastName': str(fetch_one(getLastName)),
                          'accepted': str(fetch_one(getAccepted))}

                controller = str(object) + ',' + controller

            controller = ast.literal_eval(controller[:-1])

        cursor.close()
        if(i==1):
            data = [controller]
        elif(i>1):
            data = controller
        else:
            data = [{'id': '', 'name': '', 'lastName': '', 'accepted': ''}]

        return data

    except:
        print 'errors in candidatesProcessed function'
    else:
        cnx.close()


def addCandidate(name, lastName, level, area, salary, grade):
    try:
        cnx = pyodbc.connect(dbAddress)
        cursor = cnx.cursor()
        getLastId = queries.get('DatabaseQueries', 'database.getLastIdFromCandidates')
        cursor.execute(getLastId)
        lastId = cursor.fetchone()
        if lastId is None:
            lastId = 1
        else:
            lastId = lastId[0] + 1
        lastId = str(lastId)

        insertCandidate = "insert into [Recruitment].[dbo].[candidates] " \
                          "values('"+lastId+"', '"+name+"', '"+lastName+"', '"+level+"', '"+area+"', '"+salary+"', '"+grade+"')"

        cursor.execute(insertCandidate)
        cnx.commit()

        time.sleep(1)
        processData = "exec [Recruitment].[dbo].[recruitmentProcedure]"
        cursor.execute(processData)
        cnx.commit()
        data = candidatesProcessed()
        return data

    except:
        print 'errors in addCandidate function'
    else:
        cnx.close()


#-----------------------------------------------------------------------------------------------------------------------
def fetch_one(get_value):
    cursor.execute(get_value)
    Value = cursor.fetchone()
    Value = Value[0]
    return Value


def fetch_all(get_value):
    cursor.execute(get_value)
    Value = cursor.fetchall()
    Value = [oc[0] for oc in Value]
    return Value


def fetch_all_replace(get_value):
    cursor.execute(get_value)
    Value = cursor.fetchall()
    Value = [u[0] for u in Value]
    Value = ans = ' '.join(Value).replace(' ', '\n')
    return Value

def replace(Value):
    Value = ans = ' '.join(Value).replace(' ', '\n')
    return Value
