'use strict';


var TechnicalTester = angular.module('TechnicalTester.controller', ['ngResource', 'ngAnimate', 'ui.bootstrap', 'smart-table',
 'angularModalService']);

    // Register environment in AngularJS as constant
    TechnicalTester.constant('__env', __env);


//-----------------------------------------------------Start------------------------------------------------------------
    //startCtrl
	TechnicalTester.controller('startCtrl', function($scope) {
	});


//-----------------------------------------------------List-------------------------------------------------------------
    //listCtrl
	TechnicalTester.controller('listCtrl', function($scope) {
	});

    //tableCtrl
    TechnicalTester.controller('tableCtrl', ['$rootScope', '$routeParams', 'getData',
                                     function($scope, $routeParams, Data) {
       //Get data
       $scope.displayedData = [];
       $scope.data = Data.query();
       console.log($scope.data);

    }]);

    //ModalCtrl
    TechnicalTester.controller('ModalCtrl', ['$scope', '$uibModal', function ($scope, $uibModal) {

       $scope.animationsEnabled = true;

       //Add Candidate Modal
       $scope.addCandidate = function () {
            var modalInstance = $uibModal.open({
              animation: $scope.animationsEnabled,
              templateUrl: 'newModalContent.html',
              controller: 'ModalInstanceCtrl',
            });
       };
    }]);

    TechnicalTester.controller('ModalInstanceCtrl', ['$rootScope', '$scope', '$uibModalInstance', 'postCandidate',
                         function ($rootScope, $scope, $uibModalInstance, NewCandidate) {

      //[Submit]
      $scope.addRow = function(){
          $rootScope.displayedData = [];
          $rootScope.data = [];

          //Call postCandidate service...
   		  NewCandidate.save({name:$scope.name, lastName:$scope.lastName, level:$scope.level,
   		                      area:$scope.area, salary:$scope.salary, grade:$scope.grade}, function(response){
   		     $scope.message = response.message;
   		     var globalObject = [];
             var len = response.length;
             for(var i = 0; i < len; i++) {
                var newObject = {}
                angular.forEach(response[Object.keys(response)[i]], function(value, key){
                    newObject[key] = value;
                });
                globalObject.push(newObject);
             }
             $rootScope.displayedData = [];
             $rootScope.data = globalObject;
   		  });
   		  //...and close modal
   		  $uibModalInstance.dismiss();
      };

      //[Cancel]
      $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
      };
    }]);


//-----------------------------------------------------------Home-------------------------------------------------------

    //mainCtrl
	TechnicalTester.controller('mainCtrl', ['$rootScope', function ($scope) {

	}]);