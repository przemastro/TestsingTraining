
//DEV Environment
(function (window) {
  window.__env = window.__env || {};

  // API url
  window.__env.apiUrl = 'http://localhost:5001';
  window.__env.apiUrlService = 'http://localhost\\:5001';
  window.__env.enableDebug = true;
}(this));

