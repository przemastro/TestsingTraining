'use strict';

var services = angular.module('TechnicalTester.services', ['ngResource']);


//Table list data
services.factory('getData', ['$resource',
    function ($resource) {
    return $resource(__env.apiUrlService+'/data', {}, {
        query: {method:'GET', isArray:true}
    });
}]);

//Add new candidate
services.factory('postCandidate', ['$resource',
    function ($resource) {
    return $resource(__env.apiUrlService+'/addCandidate', {}, {
        save: {method:'POST', isArray:true}
    });
}]);
