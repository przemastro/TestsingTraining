'use strict';


	// create the module and name it TechnicalTester
	angular.module('TechnicalTester', ['ngRoute', 'TechnicalTester.services', 'TechnicalTester.controller', 'ngMessages'])

	// configure routes
	   .config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
		 $routeProvider
            .when('/', {
				templateUrl : 'pages/start.html',
				controller  : 'listCtrl'
			})

			.when('/list', {
				templateUrl : 'pages/list.html',
				controller  : 'listCtrl'
			})

			.when('/start', {
            	templateUrl : 'pages/start.html',
            	controller  : 'startCtrl'
            })

	}]);